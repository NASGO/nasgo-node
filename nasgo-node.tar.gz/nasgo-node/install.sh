#!/bin/bash

function main() {
  echo "Installing ..."
  apt-get update -yqq
  apt-get install wget curl sqlite3 -yqq
  apt-get install ntp -yqq
  apt-get install ntpdate -yqq
  /etc/init.d/ntp stop
   sleep 2
   /etc/init.d/ntp start
  echo "done"
}

main
